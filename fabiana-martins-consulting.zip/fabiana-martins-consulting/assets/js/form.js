/**
 * Fabiana Martins Consulting — form.js
 * Validação leve do formulário de contato e envio via mailto (sem backend).
 * Bilíngue: detecta document.documentElement.lang (pt-BR ou en) e ajusta
 * mensagens de validação, assunto e corpo do e-mail automaticamente.
 * Para produção, recomenda-se ligar a um serviço como Formspree, Resend ou
 * uma função serverless — bastando trocar handleSubmit pelo fetch() correspondente.
 */
(function () {
  "use strict";

  var CONTACT_EMAIL = "fabianamartins.consulting@gmail.com";
  var IS_EN = (document.documentElement.lang || "").toLowerCase().indexOf("en") === 0;

  var STRINGS = IS_EN
    ? {
        nameRequired: "Please enter your full name.",
        emailInvalid: "Please enter a valid email address.",
        messageTooShort: "Tell me a bit more about your commercial challenge (min. 10 characters).",
        contactSubject: "New website contact — ",
        fieldName: "Name: ",
        fieldEmail: "Email: ",
        fieldCompany: "Company: ",
        fieldService: "Service of interest: ",
        opening: "Opening your email app to confirm the message…",
        newsletterSubject: "Newsletter subscription",
        newsletterBody: "I'd like to receive future posts. My email: ",
        newsletterSuccess: "Almost there — confirm the send in your email app.",
        emptyDash: "—"
      }
    : {
        nameRequired: "Informe seu nome completo.",
        emailInvalid: "Informe um e-mail válido.",
        messageTooShort: "Conte um pouco mais sobre o seu desafio comercial (mín. 10 caracteres).",
        contactSubject: "Novo contato pelo site — ",
        fieldName: "Nome: ",
        fieldEmail: "E-mail: ",
        fieldCompany: "Empresa: ",
        fieldService: "Serviço de interesse: ",
        opening: "Abrindo seu aplicativo de e-mail para confirmar o envio…",
        newsletterSubject: "Inscrição na newsletter",
        newsletterBody: "Quero receber os próximos conteúdos. Meu e-mail: ",
        newsletterSuccess: "Quase lá — confirme o envio no seu e-mail.",
        emptyDash: "—"
      };

  var form = document.querySelector("#contact-form");

  if (form) {
    var status = form.querySelector(".form-status");

    var setStatus = function (message, state) {
      if (!status) return;
      status.textContent = message;
      status.setAttribute("data-state", state || "");
    };

    var validate = function (data) {
      if (!data.nome || data.nome.trim().length < 2) return STRINGS.nameRequired;
      var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(data.email || "")) return STRINGS.emailInvalid;
      if (!data.mensagem || data.mensagem.trim().length < 10) return STRINGS.messageTooShort;
      return null;
    };

    form.addEventListener("submit", function (event) {
      event.preventDefault();

      var formData = new FormData(form);
      var data = Object.fromEntries(formData.entries());

      var error = validate(data);
      if (error) {
        setStatus(error, "error");
        return;
      }

      var subject = STRINGS.contactSubject + data.nome;
      var bodyLines = [
        STRINGS.fieldName + data.nome,
        STRINGS.fieldEmail + data.email,
        STRINGS.fieldCompany + (data.empresa || STRINGS.emptyDash),
        STRINGS.fieldService + (data.servico || STRINGS.emptyDash),
        "",
        data.mensagem
      ];

      var mailtoUrl =
        "mailto:" + CONTACT_EMAIL +
        "?subject=" + encodeURIComponent(subject) +
        "&body=" + encodeURIComponent(bodyLines.join("\n"));

      window.location.href = mailtoUrl;
      setStatus(STRINGS.opening, "success");
      form.reset();
    });
  }

  // Newsletter (blog.html) ---------------------------------------------------
  var newsletterForm = document.querySelector("#newsletter-form");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (event) {
      event.preventDefault();
      var email = newsletterForm.querySelector("input[type='email']").value;
      var note = newsletterForm.querySelector(".form-status");
      var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        if (note) { note.textContent = STRINGS.emailInvalid; note.setAttribute("data-state", "error"); }
        return;
      }
      window.location.href =
        "mailto:" + CONTACT_EMAIL +
        "?subject=" + encodeURIComponent(STRINGS.newsletterSubject) +
        "&body=" + encodeURIComponent(STRINGS.newsletterBody + email);
      if (note) { note.textContent = STRINGS.newsletterSuccess; note.setAttribute("data-state", "success"); }
      newsletterForm.reset();
    });
  }
})();
