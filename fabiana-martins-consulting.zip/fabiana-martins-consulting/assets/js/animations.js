/**
 * Fabiana Martins Consulting — animations.js
 * Revelação de elementos ao rolar e ativação do Dial de Reset (elemento assinatura).
 * Usa IntersectionObserver com fallback seguro caso indisponível.
 */
(function () {
  "use strict";

  var prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function revealAll(nodeList) {
    nodeList.forEach(function (el) { el.classList.add("is-visible"); });
  }

  // Escalona a revelação de itens dentro de uma mesma grade -----------------
  document.querySelectorAll("[data-reveal-group]").forEach(function (group) {
    Array.prototype.forEach.call(group.children, function (child, index) {
      child.setAttribute("data-reveal", "");
      child.style.transitionDelay = (index * 90) + "ms";
    });
  });

  var revealTargets = document.querySelectorAll("[data-reveal]");
  var dialTargets = document.querySelectorAll(".reset-dial");

  if (prefersReduced || !("IntersectionObserver" in window)) {
    revealAll(revealTargets);
    revealAll(dialTargets);
    return;
  }

  var revealObserver = new IntersectionObserver(
    function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
  );

  revealTargets.forEach(function (el) { revealObserver.observe(el); });
  dialTargets.forEach(function (el) { revealObserver.observe(el); });
})();
