# Fabiana Martins — Commercial Operations Consultant

Site institucional premium, responsivo e otimizado para SEO da consultoria de Fabiana Martins, construído como HTML/CSS/JS estático, pronto para deploy no GitHub Pages, com suporte a PWA (instalável e com funcionamento offline básico).

**Site ao vivo:** `https://martinsbi82-ux.github.io/fabiana-martins/`
**Contato:** fabianamartins.consulting@gmail.com
**LinkedIn:** [linkedin.com/in/m82yefabi](https://www.linkedin.com/in/m82yefabi/)

---

## Estrutura do projeto

```
fabiana-martins-consulting/
├── index.html          → Página inicial (PT)
├── sobre.html           → Sobre / trajetória (PT)
├── servicos.html        → Pacotes de consultoria (PT)
├── metodologia.html     → Detalhamento do Reset Comercial™ (PT)
├── blog.html            → Lista de artigos + newsletter (PT)
├── contato.html         → Formulário de contato (PT)
│
├── en/                   → Versão em inglês (mesma estrutura, mesmos assets)
│   ├── index.html
│   ├── about.html
│   ├── services.html
│   ├── methodology.html
│   ├── blog.html
│   └── contact.html
│
├── assets/
│   ├── css/
│   │   ├── variables.css   → Design tokens (cor, tipografia, espaçamento)
│   │   ├── style.css       → Componentes e layout
│   │   └── responsive.css  → Breakpoints
│   ├── js/
│   │   ├── main.js         → Navegação, menu mobile, registro do SW
│   │   ├── animations.js   → Scroll-reveal e ativação do "Dial de Reset"
│   │   └── form.js         → Validação do formulário (bilíngue, detecta o idioma da página)
│   ├── img/
│   │   ├── logo.svg        → Logotipo tipográfico
│   │   ├── hero.jpg        → Imagem editorial da home
│   │   ├── about.jpg       → Imagem editorial da página Sobre
│   │   └── icons/          → Ícones PWA e favicon (PNG)
│   └── fonts/               → (vazio — fontes carregadas via Google Fonts)
│
├── identidade-visual/    → Assinatura de e-mail e cartão digital
├── manifest.json         → Manifesto PWA
├── sw.js                 → Service worker (cache do app shell, PT + EN)
├── robots.txt
├── sitemap.xml           → Inclui as duas versões de idioma com hreflang
├── favicon.ico
├── README.md
├── LICENSE
└── .gitignore
```

## Versão em inglês

O site é bilíngue: cada página em português tem uma equivalente em `en/`, com um botão **PT ↔ EN** no cabeçalho de cada página. As duas versões:

- Compartilham o mesmo CSS, JS e imagens (nada duplicado além do HTML).
- Têm tags `hreflang` cruzadas no `<head>` e no `sitemap.xml`, para o Google entender que são traduções uma da outra (evita problema de conteúdo duplicado e ajuda a servir o idioma certo por região).
- O formulário de contato (`assets/js/form.js`) detecta o idioma pela tag `<html lang="...">` e ajusta mensagens de validação, assunto e corpo do e-mail automaticamente — não precisa de dois arquivos JS.

## Identidade visual

| Token          | Valor      | Uso                                  |
|----------------|-----------|----------------------------------------|
| `--ink`        | `#12181F` | Texto principal, fundos escuros        |
| `--paper`      | `#F2F1EC` | Fundo base                             |
| `--brass`      | `#A9812E` | Acento primário (links ativos, ícones) |
| `--teal`       | `#29424D` | Acento secundário                      |
| `--slate`      | `#5B6472` | Texto secundário                       |

**Tipografia:** Fraunces (display, títulos), Inter (corpo de texto), IBM Plex Mono (rótulos, eyebrows, dados).

**Elemento assinatura — Dial de Reset:** um mostrador semicircular com as quatro fases do método (Diagnose → Design → Deploy → Scale), usado na home e na página de metodologia, com o arco de progresso animado ao entrar na tela.

## Como publicar no GitHub Pages

1. Crie o repositório `fabiana-martins-consulting` na conta `martinsbi82-ux`.
2. Envie todos os arquivos deste projeto para a branch `main`.
3. Em **Settings → Pages**, selecione a branch `main` e a pasta raiz (`/`).
4. O site ficará disponível em `https://martinsbi82-ux.github.io/fabiana-martins/`.

> Se o repositório tiver outro nome, atualize as URLs absolutas em `sitemap.xml`, `robots.txt` e nas tags `og:url` / `canonical` de cada página HTML.

## Formulário de contato

O formulário (`contato.html`) e a newsletter (`blog.html`) funcionam hoje via `mailto:`, sem backend — o botão de envio abre o aplicativo de e-mail do visitante com a mensagem pré-preenchida para `fabianamartins.consulting@gmail.com`. Para captar leads diretamente em uma planilha ou CRM, considere ligar o `assets/js/form.js` a um serviço como Formspree, EmailJS ou uma função serverless.

## PWA

O site pode ser "instalado" (adicionar à tela inicial) em celulares e desktops compatíveis, graças ao `manifest.json` e ao `sw.js`, que também garante o carregamento das páginas já visitadas mesmo sem conexão.

## SEO

- Meta description e Open Graph únicos por página.
- `sitemap.xml` e `robots.txt` prontos.
- Dados estruturados (`schema.org/ProfessionalService`) na home.
- Marcação semântica (`<header>`, `<main>`, `<footer>`, `<nav>`, hierarquia de headings).

## Acessibilidade

- Link "Pular para o conteúdo".
- Contraste testado sobre a paleta definida.
- `prefers-reduced-motion` respeitado em todas as animações.
- Foco visível (`:focus-visible`) em todos os elementos interativos.

---

Feito para Fabiana Martins — Commercial Operations Consultant.
