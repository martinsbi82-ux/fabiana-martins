/**
 * Fabiana Martins Consulting — Service Worker
 * Cache estático simples (app shell) com atualização em segundo plano.
 */
const CACHE_NAME = "fm-consulting-v1";

const APP_SHELL = [
  "./",
  "./index.html",
  "./sobre.html",
  "./servicos.html",
  "./metodologia.html",
  "./blog.html",
  "./contato.html",
  "./en/index.html",
  "./en/about.html",
  "./en/services.html",
  "./en/methodology.html",
  "./en/blog.html",
  "./en/contact.html",
  "./assets/css/variables.css",
  "./assets/css/style.css",
  "./assets/css/responsive.css",
  "./assets/js/main.js",
  "./assets/js/animations.js",
  "./assets/js/form.js",
  "./assets/img/logo.svg",
  "./favicon.ico",
  "./manifest.json"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => null)
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => cached);

      return cached || network;
    })
  );
});
